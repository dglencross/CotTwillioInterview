﻿using System;
using System.Web.Mvc;

namespace Twilio.Web.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        
        [HttpPost]
        public ActionResult ValidatePhoneNumber(string phoneNumber)
        {
            // Create Service
            // On Index page Display result
            throw new NotImplementedException();
        }
    }
}
